document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Mensaje enviado con éxito. ¡Nos pondremos en contacto pronto!');
});